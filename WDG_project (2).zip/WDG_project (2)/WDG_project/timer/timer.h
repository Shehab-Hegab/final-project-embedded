#ifndef TIMER_H
#define TIMER_H

void Timer1_Init(void);
void Timer2_Init(void);

#endif


