#include "WDGDRV.h"
#include "WDGM.h"
#include <avr/io.h>
#include <util/delay.h>
#include "LEDM.h"
#include <avr/interrupt.h>
#include "timer.h"
#include "GPIO.h"

int main(void) {
    LED_Init();
    WDGDrv_Init();
    WDGM_Init();
    Timer1_Init();
    Timer2_Init();

    sei();

    while (1) {
        LED_Manage();//10
        _delay_ms(10);
        WDGM_MainFunction();//20
        _delay_ms(10); // Call WDGM_MainFunction every 20ms
    }
    
    return 0;
}
//-------------------------------------------------------------------------------------------------//

/*

 Scenario B:

 -Comment WDGM_MainFunction and check if the watchdog resets after 50ms.

*/

//-------------------------------------------------------------------------------------------------//

/*

 Scenario C:

 -Comment WDGM_AlivenessIndication() in LED_manage & verify the watchdog reset after 100ms.

 */

//-------------------------------------------------------------------------------------------------//

/* Scenario D:

check if the watchdog resets after 100ms.


    Main loop would be like this:

while (1) {
      LED_Manage();
      _delay_ms(5);
      WDGM_MainFunction();
      _delay_ms(15);
 }
*/
