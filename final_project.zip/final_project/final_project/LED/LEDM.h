#ifndef LEDM_H
#define LEDM_H
void LEDM_Init(void);
void LEDM_Manage(void);
#endif