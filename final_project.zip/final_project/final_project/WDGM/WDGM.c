
// manar + shehab + ibrahim + salema 


#include "WDGM.h"
#include "Std_Types.h"
#include "toggle.h"
#include "GPIO.h"


static volatile int mainFuncCalls = 0;
static volatile int lastCheckTime = 0; // To count for each 100ms, main loop = 10ms
WDGM_StatusType wdgmStatus = OK;
static volatile int wgdmMainFuncTurn = 0; // For each 20ms, main loop = 10ms
volatile int Calls = 0;

void WDGM_Init(void) {
    // The WDGM_Init shall initialize the WDGM_Internal variables.
    mainFuncCalls = 0;
    lastCheckTime = 0;
    wdgmStatus = OK;

}

void WDGM_MainFunction(void) {
    // The WDGM_MainFunction shall check the number of calls of the LEDM_MainFunction within a
    // 100ms period. If the number of calls is between 8 and 12 then the status is OK. otherwise, the
    // status is not OK. The WDGM_MainFunction shall be called periodically every 20ms.
    toggle_testPins(&DDRD, &PORTD,PIN2_ID);

    Calls++;
    // Check if 20ms has passed
    if (++wgdmMainFuncTurn >= 2) { // 2 * 10ms = 20ms
        wgdmMainFuncTurn = 0; // Reset the turn counter

        // Check if 100ms has passed
        if (++lastCheckTime >= 5) { // 5 * 20ms = 100ms
            lastCheckTime = 0; // Reset the time counter

            // Check the number of calls within 100ms
            if (mainFuncCalls >= 8 && mainFuncCalls <= 12) {
                wdgmStatus = OK;
            } else {
                wdgmStatus = NOK;
            }
            mainFuncCalls = 0; // Reset for the next 100ms period
        }
    }
}

WDGM_StatusType WDGM_PovideSuppervisionStatus(void) {
    // The WDGM_ProvideSuppervisionStatus shall provide the Status of the LEDM entity to the WDGDrv.
    return wdgmStatus;
}

void WDGM_AlivenessIndication(void) {
    // The WDGM_AlivenessIndication
    // shall be called from the LEDM_Manage function to detect its call at the correct timing.
    mainFuncCalls++;
}

























// static uint8 wdgmStatus = 0;
// static uint16 ledManageCalls = 0;
// static uint8 wdgmMainFunctionCalled = 0;

// void WDGM_Init(void) {
//     wdgmStatus = 1; // initially OK
//     ledManageCalls = 0;
//     wdgmMainFunctionCalled = 0;
// }

// void WDGM_MainFunction(void) {
// 	toggle_testPins(&DDRD, &PORTD,PIN2_ID);
//     if (ledManageCalls >= 8 && ledManageCalls <= 12) {
//         wdgmStatus = 1;
//     } else {
//         wdgmStatus = 0;
//     }
//     ledManageCalls = 0; // Reset count every 100ms
//     wdgmMainFunctionCalled = 1; // Tells that Function is called
// }

// WDGM_StatusType WDGM_ProvideSupervisionStatus(void) {
//     return wdgmStatus;
// }

// void WDGM_AlivenessIndication(void) {
//     ledManageCalls++;
// }


// int WDGM_MainFunctionStuck(void) {
//     // Check if WDGM_MainFunction was called
//     if (wdgmMainFunctionCalled) {
//         wdgmMainFunctionCalled = 0; // Reset the flag
//         return 0; // Not stuck
//     }
//     return 1; // Stuck
// }
